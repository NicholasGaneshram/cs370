### Manual for TipCalculator APP

1) Launch or Download Android Studio
2) Download the Necessary files from my repo
3) Upon, launching Android Studio, or through an emulator, open the App
4) Input any data, entering the Party Number (Total amount of People in Your Group who are Paying) and then enter the Total cost of your bill. 
5) Press Compute Tip Button
6) The Tip Row, will provide a total amount of Tip, whether it be 15, 20 or 25 percent.
7) The Total column will provide the toal amount each person has to pay, depending on which tip you choose.
8) To calculate or adjust any of the input feilds, simply click and readjust the values.

**Please Note All Totals are rounded to the nearest whole number, for better convience.
